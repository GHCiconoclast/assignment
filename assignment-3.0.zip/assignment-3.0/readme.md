# Grid World assignment #
This repository contains *Grid World* assignment for University of Bristol [COMS30106](https://COMS30106.github.io/) course.

The coursework description is available in wiki format [here](https://github.com/COMS30106/assignment/wiki).
